
LOOT_SOURCES.lootsource_haybot = {
	loot = {
		{
			list = {
				{ uuid = obj_consumable_component,		weight = 0.65, quantity =	{2, 1, 3} },
				{ uuid = obj_consumable_gas,			weight = 0.35 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_haybot_growlab = {
	loot = {
		{
			list = {
				{ uuid = obj_consumable_component,		weight = 0.35, quantity =	{2, 2, 4} },
				{ uuid = obj_consumable_gas,			weight = 0.15 },
				{ uuid = nil,		                    weight = 0.50 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_haybot_farmraid = {
	loot = {
		{
			list = {
				{ uuid = obj_consumable_component,		weight = 0.20, quantity =	{2, 2, 3} },
				{ uuid = nil,		                    weight = 0.80 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_haybot_warehouse = {
	loot = {
		{
			list = {
				{ uuid = obj_consumable_component,		weight = 0.65, quantity =	{2, 2, 4} },
				{ uuid = obj_consumable_gas,			weight = 0.35, quantity =	{2, 2, 4} },
			}
		}
	}
}
LOOT_SOURCES.lootsource_haybot_underground = {
	loot = {
		{
			list = {
				{ uuid = obj_consumable_component,		weight = 0.65, quantity = 3 },
				{ uuid = obj_consumable_gas,			weight = 0.35, quantity = 3 },
			}
		}
	}
}