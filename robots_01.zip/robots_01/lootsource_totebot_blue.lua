
LOOT_SOURCES.lootsource_totebot_blue = {
	loot = {
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_resource_circuitboard, weight = 1, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 1 },
			}
		},
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_consumable_glue, weight = 1, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 2 },
			}
		},
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_powertools_drill, weight = 0.05, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 1.0 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_totebot_blue_farmraid = {
	loot = {
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_resource_circuitboard, weight = 1, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 2 },
			}
		},
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_consumable_glue, weight = 1, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 4 },
			}
		},
		{
			count = 1,
			list = {
				{ uuid = ITEMS.obj_powertools_drill, weight = 0.025, quantity =	{1, 1, 3} },
				{ uuid = nil, weight = 1.0 },
			}
		}
	}
}