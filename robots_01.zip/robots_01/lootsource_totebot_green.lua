
LOOT_SOURCES.lootsource_totebot_green = {
	loot = {
		{
			list = {
				{ uuid = obj_resource_circuitboard,		weight = 0.75, quantity =	{2, 2, 3} },
				{ uuid = obj_resource_crudeoil,			weight = 0.25, quantity =	{2, 2, 3} }
			}
		}
	}
}
LOOT_SOURCES.lootsource_totebot_green_growlab = {
	loot = {
		{
			list = {
				{ uuid = obj_resource_circuitboard,		weight = 1.0, quantity =	{2, 2, 5} },
				{ uuid = nil,		                    weight = 5.0 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_totebot_green_farmraid = {
	loot = {
		{
			list = {
				{ uuid = obj_resource_circuitboard,		weight = 1.0, quantity =	{2, 2, 5} },
				{ uuid = nil,		                    weight = 5.0 },
			}
		}
	}
}
LOOT_SOURCES.lootsource_totebot_green_underground = {
	loot = {
		{
			list = {
				{ uuid = obj_resource_circuitboard,		weight = 0.75 },
				{ uuid = obj_resource_crudeoil,			weight = 0.25, quantity =	{2, 2, 5} },
				{ uuid = nil,		                    weight = 1.0 },
			}
		}
	}
}